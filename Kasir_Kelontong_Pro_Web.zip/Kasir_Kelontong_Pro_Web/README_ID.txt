KASIR KELONTONG PRO — VERSI WEB AWAL

FITUR SAAT INI
- Antarmuka responsif untuk HP.
- Data produk, harga, stok, keranjang, diskon, dan transaksi.
- Laporan penjualan hari ini dan riwayat transaksi.
- Ekspor CSV dan cadangan/pemulihan JSON.
- Struk dapat dicetak melalui dialog cetak browser.
- Pencarian produk dan input barcode dari scanner yang bertindak sebagai keyboard.
- PWA: manifest dan service worker untuk instalasi/akses offline setelah di-host melalui HTTPS.

PENTING
1. Versi ini menyimpan data di browser/perangkat saat ini. Belum ada login atau sinkronisasi cloud antar-HP.
2. QRIS hanya dapat dipilih sebagai metode pencatatan manual. Belum membuat QR dinamis DANA Bisnis dan tidak memverifikasi pembayaran.
3. Printer Bluetooth belum terintegrasi langsung. Dialog cetak browser tidak menjamin dukungan printer Bluetooth/ESC-POS.
4. Data lokal bisa hilang jika data browser dihapus. Gunakan fitur Unduh cadangan secara berkala.
5. Uji dahulu dengan data contoh; jangan gunakan untuk transaksi penting sebelum diuji.

CARA MEMASANG DI LAYAR UTAMA HP
1. Upload semua file dalam folder ini ke hosting HTTPS statis (misalnya GitHub Pages atau layanan hosting statis lain).
2. Buka URL hosting tersebut di Chrome Android.
3. Buka menu ⋮ lalu pilih "Tambahkan ke layar utama" atau "Instal aplikasi" jika tersedia.
4. Buka dari ikon layar utama.

Untuk sinkronisasi multi-perangkat, diperlukan backend dan autentikasi (misalnya Firebase). Untuk QRIS dinamis, perlu akses API resmi penyedia pembayaran, endpoint backend yang aman, webhook/status verification, dan pengujian transaksi. Jangan menaruh secret API di kode browser.
